-----------------------------
About: Sinbad Character Model
-----------------------------

Artist: Zi Ye
Date: 2009-2010
E-mail: omniter@gmail.com

This character is a gift to the OGRE community (http://www.ogre3d.org).
You may use this character however you wish in your own applications,
but you may NOT sell it, or any modified version of it. You do not need
to give credit to the artist, but it would be appreciated. =)

The restrictions in the text above applies to the following files:
- Sinbad.mesh
- Sinbad.skeleton
- sinbad_body.tga
- sinbad_clothes.tga
- sinbad_sword.tga
- Sword.mesh

Copyright (C) 2010 Zi Ye. All rights reserved.
